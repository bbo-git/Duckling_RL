"""meas2.py - meet een loop-policy op alle lopen-commando's.
Elk commando 4x, met de loopklok op een andere startfase (welke voet begint): de drift
hangt daar sterk van af. Getoond: gemiddelde, en tussen [] min..max over de 4 starts.
    PYTHONPATH=<tools> python meas2.py policy.onnx gait_grid.npz
"""
import sys, math, numpy as np, duckling_play_onnx as P

pol = P.Policy(sys.argv[1]); G = P.GridClock(sys.argv[2])
H = [5, 6, 7, 8]          # neck_pitch, head_pitch, head_roll, head_yaw (actuator order)
PHASES = (0.0, 0.25, 0.5, 0.75)
CMDS = (("stil", (0, 0, 0)), ("vooruit 4", (0.04, 0, 0)), ("vooruit 8", (0.08, 0, 0)), ("vooruit 12", (0.12, 0, 0)),
        ("draai L", (0.0, 0, 0.5)), ("draai R", (0.0, 0, -0.5)),
        ("bocht L", (0.08, 0, 0.3)), ("bocht R", (0.08, 0, -0.3)))   # lopen: vooruit + draaien


def yaw_of(q):
    return math.atan2(2 * (q[0] * q[3] + q[1] * q[2]), 1 - 2 * (q[2] ** 2 + q[3] ** 2))


def run(t, ph0):
    r = P.Duckling("scene_walk.xml", grid=G); r.gait_clock = True; r.phase = ph0
    J, Hq, WD, la = [], [], [], np.zeros(14)
    for k in range(500):
        a = pol(r.obs(t, np.zeros(4))); r.step(a, t)
        if k == 100:
            yaw0, p0 = yaw_of(r.d.qpos[3:7]), r.d.qpos[:2].copy()
        if k > 100:
            J.append(np.degrees(np.abs(a - la).mean())); Hq.append(r.d.qpos[r.qadr[H]].copy())
            yw = yaw_of(r.d.qpos[3:7]); dl = r.d.site('left_foot').xpos - r.d.site('right_foot').xpos
            WD.append(abs(-math.sin(yw) * dl[0] + math.cos(yw) * dl[1]) * 1000)
        la = a
        if r.fallen:
            return None
    T = len(J) * 0.02; d = r.d.qpos[:2] - p0; c, s = math.cos(yaw0), math.sin(yaw0)
    yaw = yaw_of(r.d.qpos[3:7]); Hq = np.degrees(np.array(Hq))
    return dict(vx=(c * d[0] + s * d[1]) / T * 1000, vy=(-s * d[0] + c * d[1]) / T * 1000,
                wz=math.degrees(math.atan2(math.sin(yaw - yaw0), math.cos(yaw - yaw0))) / T,
                br=np.mean(WD), tr=np.mean(J), hd=Hq.max(0) - Hq.min(0))


f = lambda v: f"{np.mean(v):6.0f} [{min(v):4.0f}..{max(v):4.0f}]"
for name, t in CMDS:
    R = [run(np.array(t, float), ph) for ph in PHASES]
    fell = sum(x is None for x in R); R = [x for x in R if x is not None]
    if not R:
        print(f"{name:11s} VALT (4/4)"); continue
    g = lambda k: [x[k] for x in R]
    print(f"{name:11s} vx {f(g('vx'))}  vy {f(g('vy'))} mm/s  draai {f(g('wz'))} gr/s  breedte {np.mean(g('br')):3.0f}"
          f"  trillen {np.mean(g('tr')):4.1f}  hoofd knik/pitch/rol/yaw {np.mean(g('hd'), 0).round(0)}"
          + (f"  VALT {fell}/4" if fell else ""))
